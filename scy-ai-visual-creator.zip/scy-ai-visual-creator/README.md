# SCY Intelligence — AI Visual Creator Portfolio

## Setup
1. `npm install`
2. Copy `.env.example` to `.env.local`
3. Add your Sanity project ID and dataset.
4. `npm run dev`

Routes: `/`, `/blog`, `/studio`.

Upload videos to Cloudinary and paste the delivery URL into a Sanity Project document. Do not commit `.env.local`.
