/** @type {import('next').NextConfig} */
module.exports={images:{remotePatterns:[{protocol:'https',hostname:'cdn.sanity.io'},{protocol:'https',hostname:'res.cloudinary.com'}]}};
