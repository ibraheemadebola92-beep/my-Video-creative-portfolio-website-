import type {Config} from 'tailwindcss';
const config:Config={darkMode:'class',content:['./app/**/*.{js,ts,jsx,tsx,mdx}','./components/**/*.{js,ts,jsx,tsx,mdx}'],theme:{extend:{fontFamily:{sans:['Inter','Arial','sans-serif']},animation:{marquee:'marquee 25s linear infinite'},keyframes:{marquee:{'0%':{transform:'translateX(0)'},'100%':{transform:'translateX(-50%)'}}}}},plugins:[]};
export default config;
