import type {Metadata} from 'next';import {Inter} from 'next/font/google';import './globals.css';import ThemeProvider from '../components/ThemeProvider';
const inter=Inter({subsets:['latin']});
export const metadata:Metadata={title:'Ibrahim Adebola — AI Visual Creator',description:'AI Visual Creator & Creative Director specializing in cinematic AI videos, promotional visuals and digital creatives.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en" suppressHydrationWarning><body className={inter.className}><ThemeProvider>{children}</ThemeProvider></body></html>}
